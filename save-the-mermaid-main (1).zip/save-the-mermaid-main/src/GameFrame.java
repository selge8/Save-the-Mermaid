import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageInputStream;
import javax.swing.*;


public class GameFrame extends JFrame {

    public GameFrame(String title) throws HeadlessException{
        super(title);
    }

    public static void main(String[] args) throws InterruptedException {

        ArrayList<Question> allQuestions = new ArrayList<>();
        ArrayList<Question> selectedCategoryQuestions = new ArrayList<>();

        int selectedCategory = 0;

        String pathToCsv = "resource/questions/questions.csv";
        BufferedReader csvReader = null;

        try {
            csvReader = new BufferedReader(new FileReader(pathToCsv));
            String row;

            while ((row = csvReader.readLine()) != null) {
                String[] data = row.split(",");
                Question question = new Question(Integer.parseInt(data[0]),Integer.parseInt(data[1]),data[2],data[3],data[4],data[5],data[6],Integer.parseInt(data[7]));
                allQuestions.add(question);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (csvReader != null) {
                    csvReader.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        GameFrame screen = new GameFrame("Save the Mermaid");

        int currentScreen=0;
        int menuScreen=1, categoryScreen=1;



        screen.setResizable(false);
        screen.setFocusable(false);

        screen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MainMenu menu = new MainMenu();
        CategorySelection categorySelection = new CategorySelection();
        QuestionPanel questionPanel = new QuestionPanel();
        Game game = new Game();

        // GAME LOOP
        while (true) {

            //MENU
            if(currentScreen == 0) {

                menu.requestFocus();

                screen.add(menu.play);
                screen.add(menu.quit);
                screen.add(menu);

                screen.pack();
                screen.setLocationRelativeTo(null);
                screen.setVisible(true);



                // Menu Screen Loop waiting for command
                while (menuScreen == 1) {

                    //Clicking play button
                    if (menu.playButton) {
                        currentScreen = 1;
                        screen.remove(menu.play);
                        screen.remove(menu.quit);
                        screen.remove(menu);
                        screen.setVisible(false);
                        menuScreen++;
                    }
                    System.out.println("Menu is ON!");
                }
            }


            //CATEGORY SELECTION
            if(currentScreen == 1) {

                categorySelection.requestFocus();

                screen.add(categorySelection.easy);
                screen.add(categorySelection.moderate);
                screen.add(categorySelection.difficult);
                screen.add(categorySelection);
                screen.pack();
                screen.setVisible(true);

                // Category Screen Loop waiting for command
                while(categoryScreen == 1){

                    if(categorySelection.easyBool || categorySelection.moderateBool || categorySelection.difficultBool){
                        currentScreen = 2;
                        screen.remove(categorySelection.easy);
                        screen.remove(categorySelection.moderate);
                        screen.remove(categorySelection.difficult);
                        screen.remove(categorySelection);
                        screen.setVisible(false);
                        if (categorySelection.easyBool) {
                            selectedCategory = 1;
                            questionPanel.setQuestionScore(10);
                            questionPanel.setQuestionCategory(1);
                        }
                        if (categorySelection.moderateBool){
                            selectedCategory = 2;
                            questionPanel.setQuestionScore(30);
                            questionPanel.setQuestionCategory(2);
                        }
                        if (categorySelection.difficultBool){
                            selectedCategory = 3;
                            questionPanel.setQuestionScore(50);
                            questionPanel.setQuestionCategory(3);
                        }

                        for (Question q: allQuestions) {
                            if(q.getQuestionCategory() == selectedCategory)
                                selectedCategoryQuestions.add(q);
                        }

                        questionPanel.setQuestions(selectedCategoryQuestions);

                        categoryScreen++;
                    }
                    System.out.println("Select Category!");
                }

            }

            //QUESTION SCREEN
            if (currentScreen == 2){

                questionPanel.requestFocus();

                screen.add(questionPanel);

                screen.pack();
                screen.setVisible(true);

                if (questionPanel.getQuestions().isEmpty() || questionPanel.continueBool){
                    currentScreen = 3;
                    game.setTimeInSeconds(questionPanel.getScore()*3);
                    game.setGameIsOn(true);
                    screen.remove(questionPanel);

                    screen.setVisible(false);
                }

                System.out.println("Question Time!");
            }

            //GAME SCREEN
            if (currentScreen == 3){

                game.requestFocus();

                screen.add(game);

                screen.pack();
                screen.setVisible(true);

                if(!game.isGameIsOn()){
                    game.screenCleaner();
                    game.endScreenScore();
                }

                System.out.println("Game Time!");
            }
        }

    }

}
