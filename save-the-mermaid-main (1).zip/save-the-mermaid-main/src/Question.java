public class Question {

    private int questionNo;
    private int questionCategory;
    private String questionText;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private int correctChoice;

    public Question(int questionNo, int questionCategory, String questionText, String optionA, String optionB, String optionC, String optionD, int correctChoice) {
        this.questionNo = questionNo;
        this.questionCategory = questionCategory;
        this.questionText = questionText;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correctChoice = correctChoice;
    }

    public int getQuestionNo() {
        return questionNo;
    }

    public int getQuestionCategory() {
        return questionCategory;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public int getCorrectChoice() {
        return correctChoice;
    }
}
