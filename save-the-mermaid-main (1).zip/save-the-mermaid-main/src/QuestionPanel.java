import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageInputStream;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class QuestionPanel extends JPanel implements ActionListener {

    private int questionCategory;
    private Random randomGenerator;
    private ArrayList<Question> questions;
    private BufferedImage bg;
    private Image buttonIcon, continueIcon, continueHover, continueClick;
    private int questionIndex = 0;
    private int questionScore = 0;
    private int score = 0;
    private JLabel questionLabel;
    private JButton optionA, optionB, optionC, optionD;
    JButton continueButton;
    private Font customFont;
    boolean continueBool;
    public QuestionPanel(){

        questions = new ArrayList<>();
        continueBool = false;
        randomGenerator = new Random();

        //SCREEN SIZE
        setPreferredSize(new Dimension(960,640));
        setLayout(null);

        try {
            bg = ImageIO.read(new FileImageInputStream(new File("resource/images/emptyBackground.png")));

            buttonIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/questionButton.png")));

            continueIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/continueNormal.png")));
            continueHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/continueHover.png")));
            continueClick = ImageIO.read(new FileImageInputStream(new File("resource/buttons/continueClick.png")));

            customFont = Font.createFont(Font.TRUETYPE_FONT, new File("resource/fonts/8bit.ttf")).deriveFont(18f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(customFont);

        } catch (IOException|FontFormatException e) {
            e.printStackTrace();
        }

        questionLabel = new JLabel();
        questionLabel.setFont(customFont);
        questionLabel.setBounds(50,20,860,300);
        questionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        questionLabel.setForeground(new Color(121, 55, 132, 255));
        add(questionLabel);

        optionA = new JButton();
        optionA.setBounds(85,280,380,70);
        optionA.setFont(customFont);
        optionA.setOpaque(false);
        optionA.setContentAreaFilled(false);
        optionA.setBorder(null);
        optionA.setMargin(new Insets(0, 0, 0, 0));
        optionA.setIcon(new ImageIcon(buttonIcon));
        optionA.setHorizontalTextPosition(JLabel.CENTER);
        optionA.setVerticalTextPosition(JLabel.CENTER);
        optionA.setForeground(new Color(121, 55, 132, 255));
        optionA.addActionListener(this);

        optionB = new JButton();
        optionB.setBounds(495,280,380,70);
        optionB.setFont(customFont);
        optionB.setOpaque(false);
        optionB.setContentAreaFilled(false);
        optionB.setBorder(null);
        optionB.setMargin(new Insets(0, 0, 0, 0));
        optionB.setIcon(new ImageIcon(buttonIcon));
        optionB.setHorizontalTextPosition(JLabel.CENTER);
        optionB.setVerticalTextPosition(JLabel.CENTER);
        optionB.setForeground(new Color(121, 55, 132, 255));
        optionB.addActionListener(this);

        optionC = new JButton();
        optionC.setBounds(85,380,380,70);
        optionC.setFont(customFont);
        optionC.setOpaque(false);
        optionC.setContentAreaFilled(false);
        optionC.setBorder(null);
        optionC.setMargin(new Insets(0, 0, 0, 0));
        optionC.setIcon(new ImageIcon(buttonIcon));
        optionC.setHorizontalTextPosition(JLabel.CENTER);
        optionC.setVerticalTextPosition(JLabel.CENTER);
        optionC.setForeground(new Color(121, 55, 132, 255));
        optionC.addActionListener(this);

        optionD = new JButton();
        optionD.setBounds(495,380,380,70);
        optionD.setFont(customFont);
        optionD.setOpaque(false);
        optionD.setContentAreaFilled(false);
        optionD.setBorder(null);
        optionD.setMargin(new Insets(0, 0, 0, 0));
        optionD.setIcon(new ImageIcon(buttonIcon));
        optionD.setHorizontalTextPosition(JLabel.CENTER);
        optionD.setVerticalTextPosition(JLabel.CENTER);
        optionD.setForeground(new Color(121, 55, 132, 255));
        optionD.addActionListener(this);

        add(optionA);
        add(optionB);
        add(optionC);
        add(optionD);

        //Continue button
        continueButton = new JButton();
        continueButton.setBounds(412,560,135,70);
        continueButton.setIcon(new ImageIcon(continueIcon));
        continueButton.addActionListener(e -> continueButtonPressed());
        continueButton.setOpaque(false);
        continueButton.setContentAreaFilled(false);
        continueButton.setBorderPainted(false);
        continueButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                continueButton.setIcon(new ImageIcon(continueHover));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                continueButton.setIcon(new ImageIcon(continueIcon));
            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                continueButton.setIcon(new ImageIcon(continueClick));
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                continueButton.setIcon(new ImageIcon(continueIcon));
            }
        } );

        add(continueButton);
    }

    private void continueButtonPressed() {
        continueBool = true;
    }

    public void displayQuestion() {
        if (!questions.isEmpty()) {
            questionIndex = randomGenerator.nextInt(questions.size());
            Question currentQuestion = questions.get(questionIndex);
            questionLabel.setText(currentQuestion.getQuestionText());
            optionA.setText(currentQuestion.getOptionA());
            optionA.setEnabled(true);
            optionB.setText(currentQuestion.getOptionB());
            optionB.setEnabled(true);
            optionC.setText(currentQuestion.getOptionC());
            optionC.setEnabled(true);
            optionD.setText(currentQuestion.getOptionD());
            optionD.setEnabled(true);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawImage(bg, 0, 0, 960, 640, null);
        g.setColor(new Color(121, 55, 132, 255));
        g.fillRect(0, 40, 960, 5);
        g.setFont(customFont);
        g.drawString("POINTS   " + score, 8, 28);
        if(questionCategory == 1)
            g.drawString("EASY QUESTIONS",375,28);
        else if(questionCategory == 2)
            g.drawString("MODERATE QUESTIONS",335,28);
        else if(questionCategory == 3)
            g.drawString("DIFFICULT QUESTIONS",335,28);
    }
    @Override
    public void repaint() {
        // TODO Auto-generated method stub
        super.repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton clickedButton = (JButton) e.getSource();
        Question currentQuestion = questions.get(questionIndex);

        if( (clickedButton == optionA && currentQuestion.getCorrectChoice() == 0) || (clickedButton == optionB && currentQuestion.getCorrectChoice() == 1) || (clickedButton == optionC && currentQuestion.getCorrectChoice() == 2) || (clickedButton == optionD && currentQuestion.getCorrectChoice() == 3)){
            score += questionScore;
        }

        questions.remove(questionIndex);

        for (Question q: questions) {
            System.out.println(q.toString());
        }
        displayQuestion();
        repaint();
    }

    public void setQuestions(ArrayList<Question> questions) {
        this.questions = questions;
        if(!questions.isEmpty())
            displayQuestion();
    }

    public void setQuestionScore(int questionScore) {
        this.questionScore = questionScore;
    }

    public void setQuestionCategory(int questionCategory) {
        this.questionCategory = questionCategory;
    }

    public int getScore() {
        return score;
    }

    public ArrayList<Question> getQuestions() {
        return questions;
    }
}
