import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageInputStream;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public class Game extends JPanel implements ActionListener {

    Timer timer = new Timer(1000,this);
    private int mermaidCount = 0;
    private int gameScore = 0;
    private int timeInSeconds = 0;
    private BufferedImage gameBg,gameEndBg;
    private Image upIcon, upHover, upDisable, downIcon, downHover, downDisable, rightIcon, rightHover, rightDisable,
            leftIcon, leftHover, leftDisable, mermaidIcon, playerIcon;
    private JButton up, down, right, left;
    private JLabel scoreLabel, timeLabel, endScreenScore;
    private Font customFont, customFontTime, customFontScore;
    private int[][] matrix = new int[6][6];
    private int playerX, playerY;
    private boolean gameIsOn;

    public Game() {
        //SCREEN SIZE
        setPreferredSize(new Dimension(960,640));
        setLayout(null);
        gameIsOn = true;

        try {
            gameBg = ImageIO.read(new FileImageInputStream(new File("resource/images/gameBg.png")));
            gameEndBg = ImageIO.read(new FileImageInputStream(new File("resource/images/gameEndBg.png")));

            upIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/upNormal.png")));
            upHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/upHover.png")));
            upDisable = ImageIO.read(new FileImageInputStream(new File("resource/buttons/upDisabled.png")));

            downIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/downNormal.png")));
            downHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/downHover.png")));
            downDisable = ImageIO.read(new FileImageInputStream(new File("resource/buttons/downDisabled.png")));

            rightIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/rightNormal.png")));
            rightHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/rightHover.png")));
            rightDisable = ImageIO.read(new FileImageInputStream(new File("resource/buttons/rightDisabled.png")));

            leftIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/leftNormal.png")));
            leftHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/leftHover.png")));
            leftDisable = ImageIO.read(new FileImageInputStream(new File("resource/buttons/leftDisabled.png")));

            mermaidIcon = ImageIO.read(new FileImageInputStream(new File("resource/images/mermaidIcon.png")));

            playerIcon = ImageIO.read(new FileImageInputStream(new File("resource/images/playerIcon.png")));

            customFont = Font.createFont(Font.TRUETYPE_FONT, new File("resource/fonts/8bit.ttf")).deriveFont(30f);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(customFont);

            customFontTime = Font.createFont(Font.TRUETYPE_FONT, new File("resource/fonts/8bit.ttf")).deriveFont(16f);
            ge.registerFont(customFontTime);

            customFontScore = Font.createFont(Font.TRUETYPE_FONT, new File("resource/fonts/8bit.ttf")).deriveFont(48f);
            ge.registerFont(customFontScore);

        } catch (IOException|FontFormatException e) {
            e.printStackTrace();
        }

        placeMermaids(4);
        placePlayer();

        initializeButtons();

        up.setBounds(762,460,70,70);
        down.setBounds(762,550,70,70);
        left.setBounds(672,550,70,70);
        right.setBounds(852,550,70,70);

        add(up);
        add(left);
        add(right);
        add(down);

        scoreLabel = new JLabel();
        scoreLabel.setFont(customFont);
        scoreLabel.setBounds(725,272,165,35);
        scoreLabel.setHorizontalAlignment(SwingConstants.CENTER);
        scoreLabel.setForeground(new Color(246, 187, 255, 255));
        scoreLabel.setText("0");
        add(scoreLabel);

        timeLabel = new JLabel();
        timeLabel.setFont(customFontTime);
        timeLabel.setBounds(725,376,165,35);
        timeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        timeLabel.setForeground(new Color(246, 187, 255, 255));
        add(timeLabel);

        endScreenScore = new JLabel();
        endScreenScore.setFont(customFontScore);
        endScreenScore.setBounds(0,220,960,50);
        endScreenScore.setHorizontalAlignment(SwingConstants.CENTER);
        endScreenScore.setForeground(new Color(121, 55, 132, 255));

        timer.start();
    }

    private void placeMermaids(int count) {
        mermaidCount += count;
        int curr = 0;
        Random rand = new Random();

        while (curr < count) {

            int x = rand.nextInt(6);
            int y = rand.nextInt(6);

            System.out.println("Attempting to place mermaid at: [" + x + "][" + y + "]");

            if (matrix[x][y] == 0) {
                matrix[x][y] = 1;
                curr++;
                System.out.println("Placed mermaid " + curr + " at: [" + x + "][" + y + "]");
            }
        }
    }

    private void placePlayer() {
        Random rand = new Random();
        while (true) {
            int x = rand.nextInt(6);
            int y = rand.nextInt(6);

            if (matrix[x][y] == 0) {
                matrix[x][y] = 2;
                playerX = x;
                playerY = y;
                break;
            }
        }
    }

    private void initializeButtons() {
       //Up Button
        up = new JButton();
        up.setIcon(new ImageIcon(upIcon));
        up.setOpaque(false);
        up.setContentAreaFilled(false);
        up.setBorderPainted(false);
        up.addActionListener(this);
        up.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                up.setIcon(new ImageIcon(upHover));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                up.setIcon(new ImageIcon(upIcon));
            }
        } );

        //Down Button
        down = new JButton();
        down.setIcon(new ImageIcon(downIcon));
        down.setOpaque(false);
        down.setContentAreaFilled(false);
        down.setBorderPainted(false);
        down.addActionListener(this);
        down.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                down.setIcon(new ImageIcon(downHover));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                down.setIcon(new ImageIcon(downIcon));
            }
        } );

        //Left Button
        left = new JButton();
        left.setIcon(new ImageIcon(leftIcon));
        left.setOpaque(false);
        left.setContentAreaFilled(false);
        left.setBorderPainted(false);
        left.addActionListener(this);
        left.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                left.setIcon(new ImageIcon(leftHover));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                left.setIcon(new ImageIcon(leftIcon));
            }
        } );

        //Right Button
        right = new JButton();
        right.setIcon(new ImageIcon(rightIcon));
        right.setOpaque(false);
        right.setContentAreaFilled(false);
        right.setBorderPainted(false);
        right.addActionListener(this);
        right.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                right.setIcon(new ImageIcon(rightHover));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                right.setIcon(new ImageIcon(rightIcon));
            }
        } );
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if(gameIsOn){
            g.drawImage(gameBg, 0, 0, 960, 640, null);

            // Draw the 6x6 grid matrix
            for (int y = 0; y < matrix.length; y++) {
                for (int x = 0; x < matrix[y].length; x++) {
                    if (matrix[x][y] == 1) {
                        g.drawImage(mermaidIcon, (x * 104)+10, (y * 104)+10, 100, 100, null);
                    } else if (matrix[x][y] == 2) {
                        g.drawImage(playerIcon, (playerX * 104)+10, (playerY * 104)+10, 100, 100, null);
                    }
                }
            }
        }
        else{
            g.drawImage(gameEndBg, 0, 0, 960, 640, null);
        }
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == up && playerY > 0) {
            if (matrix[playerX][playerY - 1] == 1) {
                removeMermaidAt(playerX,playerY-1);
            }
            matrix[playerX][playerY] = 0;
            playerY--;
            matrix[playerX][playerY] = 2;
        } else if (e.getSource() == down && playerY < 5) {
            if (matrix[playerX][playerY + 1] == 1) {
                removeMermaidAt(playerX,playerY+1);
            }
            matrix[playerX][playerY] = 0;
            playerY++;
            matrix[playerX][playerY] = 2;
        } else if (e.getSource() == right && playerX < 5) {
            if (matrix[playerX + 1][playerY] == 1) {
                removeMermaidAt(playerX+1,playerY);
            }
            matrix[playerX][playerY] = 0;
            playerX++;
            matrix[playerX][playerY] = 2;
        } else if (e.getSource() == left && playerX > 0) {
            if (matrix[playerX - 1][playerY] == 1) {
                removeMermaidAt(playerX-1,playerY);
            }
            matrix[playerX][playerY] = 0;
            playerX--;
            matrix[playerX][playerY] = 2;
        }

        if (timeInSeconds > 0) {
            timeInSeconds--;
            int minutes = timeInSeconds / 60;
            int seconds = timeInSeconds % 60;

            String timeText = String.format("%02d m %02d s", minutes, seconds);
            timeLabel.setText(timeText);

            timeLabel.repaint();
        } else {
            gameIsOn = false;
        }

        repaint();
    }

    private void removeMermaidAt(int x, int y) {
        gameScore += 100;
        scoreLabel.setText(String.valueOf(gameScore));
        mermaidCount--;
        if(mermaidCount == 0)
            placeMermaids(4);
    }

    public void screenCleaner(){
        remove(scoreLabel);
        remove(timeLabel);
        remove(up);
        remove(down);
        remove(left);
        remove(right);
    }

    public void endScreenScore(){
        endScreenScore.setText(String.valueOf(gameScore));
        add(endScreenScore);
    }
    public void setTimeInSeconds(int timeInSeconds) {
        this.timeInSeconds = timeInSeconds;
    }

    public void setGameIsOn(boolean gameIsOn) {
        this.gameIsOn = gameIsOn;
    }

    public boolean isGameIsOn() {
        return gameIsOn;
    }
}