import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageInputStream;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class CategorySelection extends JPanel implements ActionListener {

    private BufferedImage bg;
    private Image easyIcon, easyHover, easyClick, moderateIcon, moderateHover, moderateClick, difficultIcon, difficultHover, difficultClick;
    JButton easy, moderate, difficult;
    boolean easyBool, moderateBool, difficultBool;


    public CategorySelection(){

        easyBool =false;
        moderateBool = false;
        difficultBool = false;

        //SCREEN SIZE
        setPreferredSize(new Dimension(960,640));


        //BACKGROUND & ICONS
        try {
            bg = ImageIO.read(new FileImageInputStream(new File("resource/images/categorySelection.png")));

            easyIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/easyIcon.png")));
            easyHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/easyHover.png")));
            easyClick = ImageIO.read(new FileImageInputStream(new File("resource/buttons/easyClick.png")));

            moderateIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/moderateIcon.png")));
            moderateHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/moderateHover.png")));
            moderateClick = ImageIO.read(new FileImageInputStream(new File("resource/buttons/moderateClick.png")));

            difficultIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/difficultIcon.png")));
            difficultHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/difficultHover.png")));
            difficultClick = ImageIO.read(new FileImageInputStream(new File("resource/buttons/difficultClick.png")));

        } catch (IOException e) {
            e.printStackTrace();
        }

        //BUTTONS

        //Easy button
        easy = new JButton();
        easy.setBounds(412,300,135,70);
        easy.setIcon(new ImageIcon(easyIcon));
        easy.addActionListener(e -> easyButtonPressed());
        easy.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                easy.setIcon(new ImageIcon(easyHover));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                easy.setIcon(new ImageIcon(easyIcon));
            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                easy.setIcon(new ImageIcon(easyClick));
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                easy.setIcon(new ImageIcon(easyIcon));
            }
        } );


        //Credits button
        moderate = new JButton();
        moderate.setBounds(412 ,390,135,70);
        moderate.setIcon(new ImageIcon(moderateIcon));
        moderate.addActionListener(e -> moderateButtonPressed());
        moderate.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                moderate.setIcon(new ImageIcon(moderateHover));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                moderate.setIcon(new ImageIcon(moderateIcon));
            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                moderate.setIcon(new ImageIcon(moderateClick));
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                moderate.setIcon(new ImageIcon(moderateIcon));
            }
        } );

        //Quit button
        difficult = new JButton();
        difficult.setBounds(412,480,135,70);
        difficult.setIcon(new ImageIcon(difficultIcon));
        difficult.addActionListener(e -> difficultButtonPressed());
        difficult.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                difficult.setIcon(new ImageIcon(difficultHover));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                difficult.setIcon(new ImageIcon(difficultIcon));
            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                difficult.setIcon(new ImageIcon(difficultClick));
            }
        } );

        //Button transparent
        easy.setOpaque(false);
        easy.setContentAreaFilled(false);
        easy.setBorderPainted(false);
        difficult.setOpaque(false);
        difficult.setContentAreaFilled(false);
        difficult.setBorderPainted(false);
        moderate.setOpaque(false);
        moderate.setContentAreaFilled(false);
        moderate.setBorderPainted(false);
    }

    public void easyButtonPressed(){
        easyBool =true;
    }

    public void moderateButtonPressed(){
        moderateBool = true;
    }

    public void difficultButtonPressed(){
        difficultBool = true;
    }


    @Override
    public void paint(Graphics g) {
        g.drawImage(bg, 0, 0, 960, 640, null);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
