import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageInputStream;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class MainMenu extends JPanel implements ActionListener {

    private BufferedImage menu;
    private Image playIcon, playHover, playClick, quitIcon, quitHover, quitClick;
    JButton play, quit;
    boolean playButton;


    public MainMenu(){
        //SCREEN SIZE
        setPreferredSize(new Dimension(960,640));

        //CLOSE MENU
        playButton =false;

        //BACKGROUND & ICONS
        try {
            menu = ImageIO.read(new FileImageInputStream(new File("resource/images/background.png")));

            playIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/playNormal.png")));
            playHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/playHover.png")));
            playClick = ImageIO.read(new FileImageInputStream(new File("resource/buttons/playClick.png")));

            quitIcon = ImageIO.read(new FileImageInputStream(new File("resource/buttons/quitNormal.png")));
            quitHover = ImageIO.read(new FileImageInputStream(new File("resource/buttons/quitHover.png")));
            quitClick = ImageIO.read(new FileImageInputStream(new File("resource/buttons/quitClick.png")));

        } catch (IOException e) {
            e.printStackTrace();
        }

        //BUTTONS

        //Play button
        play = new JButton();
        play.setBounds(330,390,135,70);
        play.setIcon(new ImageIcon(playIcon));
        play.addActionListener(e -> playButtonPressed());
        play.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                play.setIcon(new ImageIcon(playHover));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                play.setIcon(new ImageIcon(playIcon));
            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                play.setIcon(new ImageIcon(playClick));
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                super.mouseReleased(e);
                play.setIcon(new ImageIcon(playIcon));
            }
        } );

        //Quit button
        quit = new JButton();
        quit.setBounds(495,390,135,70);
        quit.setIcon(new ImageIcon(quitIcon));
        quit.addActionListener(e -> quitButtonPressed());
        quit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                quit.setIcon(new ImageIcon(quitHover));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                quit.setIcon(new ImageIcon(quitIcon));
            }

            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                quit.setIcon(new ImageIcon(quitClick));
            }
        } );

        //Button transparent
        play.setOpaque(false);
        play.setContentAreaFilled(false);
        play.setBorderPainted(false);
        quit.setOpaque(false);
        quit.setContentAreaFilled(false);
        quit.setBorderPainted(false);
    }

    public void playButtonPressed(){
        playButton =true;
    }

    public void quitButtonPressed(){
        System.exit(0);
    }


    @Override
    public void paint(Graphics g) {
        g.drawImage(menu, 0, 0, 960, 640, null);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
